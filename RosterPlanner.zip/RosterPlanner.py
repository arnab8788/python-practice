import os
import random

var_Employee_Filename = input("Enter the 'Pipe Delimited' Employee List File Name (with complete folder path): ")
var_Seat_Available = int(input("Enter the Total Number of Seat Available: "))
var_Working_Days_In_Week = int(input("What is the expected number of working days in a week: "))

if os.path.isfile(var_Employee_Filename):
    print(f"\nINFO: \tValid File Located - {var_Employee_Filename}")

    with open(var_Employee_Filename, mode="r", newline="") as var_File_Read:
        var_List_Employee = var_File_Read.readlines()
        var_Total_Employee = len(var_List_Employee) - 1

        var_Pipe_Delimiter_Counter = 0

        for var_Index, var_Record in enumerate(var_List_Employee):
            var_List_Employee[var_Index] = var_Record.replace("\n", "").replace("\r", "")
            var_Pipe_Delimiter_Counter = var_Pipe_Delimiter_Counter + var_Record.count("|")

        if var_Pipe_Delimiter_Counter == len(var_List_Employee):
            print(f"\nINFO: \tThe File is properly pipe delimited")
            print(f"\nINFO: \tTotal Employee Count in the File = {var_Total_Employee}")
            del var_List_Employee[0]
        elif var_Pipe_Delimiter_Counter < len(var_List_Employee):
            print(f"\nERROR: \tDelimiter '|' is missing in few records in the File")
            print(f"\nINFO: \tExiting the Script")
            exit(1)
        elif var_Pipe_Delimiter_Counter > len(var_List_Employee):
            print(f"\nERROR: \tDelimiter '|' is more than expected in the File")
            print(f"\nINFO: \tExiting the Script")
            exit(1)

else:
    print(f"\nERROR: \tInvalid Filename - {var_Employee_Filename}")
    print(f"\nINFO: \tExiting the Script")
    exit(1)

random.shuffle(var_List_Employee)

var_Total_Seat_Available_Over_Week = var_Seat_Available * 5
var_Total_Seat_Required_Over_Week = var_Total_Employee * var_Working_Days_In_Week

if var_Total_Seat_Required_Over_Week <= var_Total_Seat_Available_Over_Week:
    print(f"\nINFO: \tThe solution for the roster is feasible")
    print(f"\t\tTotal Seating Capacity Over the Week = {var_Seat_Available} x 5 = {var_Total_Seat_Available_Over_Week}")
    print(f"\t\tTotal Seating Required Over the Week = {var_Total_Employee} x {var_Working_Days_In_Week} = {var_Total_Seat_Required_Over_Week}")
else:
    print(f"\nERROR: \tThe solution for the roster is NOT feasible")
    print(f"\t\tTotal Seating Capacity Over the Week = {var_Seat_Available} x 5 = {var_Total_Seat_Available_Over_Week}")
    print(f"\t\tTotal Seating Required Over the Week = {var_Total_Employee} x {var_Working_Days_In_Week} = {var_Total_Seat_Required_Over_Week}")
    print(f"\nINFO: \tExiting the Script")
    exit(1)

var_Dict_Roster = {}
for var_Emp_No in range(1, var_Total_Employee + 1):

    var_EmployeeID = var_List_Employee[var_Emp_No - 1].split("|")[0]
    var_EmployeeName = var_List_Employee[var_Emp_No - 1].split("|")[1]

    var_Dict_Roster[var_EmployeeID] = {"Name": var_EmployeeName, "Days": []}

    for var_Day_No in range(var_Working_Days_In_Week):
        var_Working_Day = (var_Emp_No + var_Day_No) % 5
        var_Dict_Roster[var_EmployeeID]["Days"].append(var_Working_Day)

    var_Dict_Roster[var_EmployeeID]["Days"].sort()


with open("Employee_Roster_Plan.csv", mode="w", newline="") as var_File_Write:

    var_File_Write.write("EmployeeID,EmployeeName,Monday,Tuesday,Wednesday,Thursday,Friday\n")

    var_Monday_Counter = 0
    var_Tuesday_Counter = 0
    var_Wednesday_Counter = 0
    var_Thursday_Counter = 0
    var_Friday_Counter = 0

    for var_EmployeeID, var_SubDict in var_Dict_Roster.items():

        var_EmployeeName = var_SubDict["Name"]
        var_List_WorkDays = var_SubDict["Days"]

        var_Line = var_EmployeeID + "," + var_EmployeeName

        if 0 in var_List_WorkDays:
            var_Line = var_Line + ",Y"
            var_Monday_Counter = var_Monday_Counter + 1
        else:
            var_Line = var_Line + ","

        if 1 in var_List_WorkDays:
            var_Line = var_Line + ",Y"
            var_Tuesday_Counter = var_Tuesday_Counter + 1
        else:
            var_Line = var_Line + ","

        if 2 in var_List_WorkDays:
            var_Line = var_Line + ",Y"
            var_Wednesday_Counter = var_Wednesday_Counter + 1
        else:
            var_Line = var_Line + ","

        if 3 in var_List_WorkDays:
            var_Line = var_Line + ",Y"
            var_Thursday_Counter = var_Thursday_Counter + 1
        else:
            var_Line = var_Line + ","

        if 4 in var_List_WorkDays:
            var_Line = var_Line + ",Y"
            var_Friday_Counter = var_Friday_Counter + 1
        else:
            var_Line = var_Line + ","

        var_File_Write.write(var_Line + "\n")

print(f"\nINFO: \tSeat Utilization Details: ")
print(f"\t\tMonday\t=\t{round(var_Monday_Counter / var_Seat_Available * 100, 2)}%\tSeat Occupancy = {var_Monday_Counter} / {var_Seat_Available}")
print(f"\t\tTuesday\t=\t{round(var_Tuesday_Counter / var_Seat_Available * 100, 2)}%\tSeat Occupancy = {var_Tuesday_Counter} / {var_Seat_Available}")
print(f"\t\tWednesday =\t{round(var_Wednesday_Counter / var_Seat_Available * 100, 2)}%\tSeat Occupancy = {var_Wednesday_Counter} / {var_Seat_Available}")
print(f"\t\tThursday =\t{round(var_Thursday_Counter / var_Seat_Available * 100, 2)}%\tSeat Occupancy = {var_Thursday_Counter} / {var_Seat_Available}")
print(f"\t\tFriday\t=\t{round(var_Friday_Counter / var_Seat_Available * 100, 2)}%\tSeat Occupancy = {var_Friday_Counter} / {var_Seat_Available}")

print(f"\nINFO: \tRoster File generated in the same path of Employee Details File - Employee_Roster_Plan.csv")
